use master create database bootstrap go
use bootstrap go
create table menu (
    id int not null primary key,
    menuName NVARCHAR(30),
    link text
)

CREATE TABLE content (
    id int not null PRIMARY key,
    title NVARCHAR(100),
    moTa NVARCHAR(300) 
)

CREATE TABLE ref (
    idmn int not null,
    idct int not null,
    sta bit
)

create TABLE usr (
    id int not null PRIMARY key,
    uname NVARCHAR(30),
    PASS NVARCHAR(30)
)
go
create proc show_all as 
BEGIN
    SELECT * FROM menu;
    SELECT * FROM content;
    SELECT * FROM ref;
    SELECT * FROM usr;
END

GO
exec show_all 
go

insert into menu VALUEs
(1,'Home','index.php'),
(2,'Features','menu.php?ver=1'),
(3,'Product','menu.php?ver=2'),
(4,'FAQ','menu.php?ver=3'),
(5,'About','menu.php?ver=4')


INSERT into usr VALUES
(1,'hxt','hxt2001')

select count(*) as 'count' from usr
