<?php
    $serverName = "DESKTOP-UDNMSM4\\MSSQLSERVER"; //serverName\instanceName
    $con = new PDO("sqlsrv:Server=localhost;Database=bootstrap");
    // echo $_POST['usr'].'  '.$_POST['pass'];
    $usr = $_POST['usr'];
    $pass = $_POST['pass'];
    if(isset($_POST['dn'])) {
        $sql = "SELECT * FROM usr";
        $kq = $con->query($sql);

        $i=0;
        while($result = $kq->fetch(PDO::FETCH_ASSOC)) {
            if($result['uname']==$usr && $result['PASS']==$pass) {
                $i=1;
            }
        }
        if($i==1) header('Location: index.html');
        else {
            header('Location: login.php?id=2');
        }
    } else if(isset($_POST['dk'])) {
        $sql = "SELECT MAX(id) AS 'max' FROM usr";
        $kq = $con->query($sql);
        $result = $kq->fetch(PDO::FETCH_ASSOC);
        $id =  $result['max'] + 1; 

        $sql = "SELECT * FROM usr";
        $kq = $con->query($sql);

        $i=0;
        while($result = $kq->fetch(PDO::FETCH_ASSOC)) {
            if($result['uname']==$usr ) {
                $i=1;
            }
        }
        if($i==1) header('Location: login.php?id=3');
        else {
            $sql = "INSERT INTO usr VALUES (?,?,?)";
            $stmt = $con->prepare($sql);
            $stmt->execute([$id,$usr,$pass]);
            echo '<script>alert("Đăng kí thành công");</script>';
            header('Location: index.html');
        }
    }

?>