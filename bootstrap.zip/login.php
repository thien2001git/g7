<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1920, initial-scale=1.0">
    <title>Đăng kí | Đăng nhập</title>
    <link rel="stylesheet" href="node_modules\bootstrap\dist\css\bootstrap.css">
</head>
<body class = "container-fluid" style="background-image: url(https://lh3.googleusercontent.com/78qJygrhVdoOqHLLIsPJcPSOuRAoX9md6dWXIEOBd2hEdevowP5uJ8AUuzcUiclCAqelndXHOixex3B9QrcNA5cV0hOPd40uDF2bkvPsEaYWyIKo6HDp01EAYL_VPZGAiD7IkiRw6K6AAFoM8OKIQs3IhiO0EhfLry_Y7NsR0vBykLu1akaxhuSd0iz0VU3fqgEkoJid-Ca2WXAe2LFPQXiDRA8BWwKP-stPTcUmtrt2qhiwrZr1jM05rE631n3XymSbCG4i_4He8BVf_ZRCHj_KvO6d_ldtt1w9qSzsS5gIXczMc3pRqp1TlDLtrJ_1vqsQZUT4oiMup-PStom3GvuLi_QtoZ93TUzhJzCYcOcAjZaWAAjTr08VbZ6OmGCxi-bjrVAagI2pBrC5zOUPTO4ItYzcGcDvxG4u2jkpwyrYFATo053ijMQ39l_2vYECCh2FPpQdvVOelPX-ftS_6IYgatjy696EnRoqadONMMKNWDrcWnNmXTffsbWj5jCWOpR9kIdq5zZQvD7BB5Ewk18f-u_YjugeVBHuW5WYNMFQSNKq0wd37D4UGg6Iy5pdgyN5ZysaktU19O-zFsg6k6Av2JrRWW20c8VRV11gsAn-JczwBtxsdASDlf4z__sG6XfkhEhAedDsdhMBb8xPPnudeIXx8bjfY8lGG0C5QBvs5yRQlgluyQI5Qc1YL2giUDVbsgpl5uSzAEhwY6gwt10=w1674-h953-no?authuser=0);">
<header class="row">
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Nhóm 7</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav me-auto mb-2 mb-md-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Product</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">FAQ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?id=0">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?id=1">Sign up</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                        </li> -->
                    </ul>
                    
                </div>
            </div>
        </nav>
    </header>
    <br><br><br><br>
    <div class="row" style="color: #ccc;">

        <div class="col" style="justify-content: center;">
            <br><br><br>
            <br><br><br>
            <br><br><br>

            <h1 style="text-align: center; text-shadow: 2px 2px 2px rgb(20, 17, 17);">Welcome to Group 7 site</h1>
            <br><br>
            <form action="t.php" method="post">
                <!-- <div class="input-group mb-3"> -->
                <div class="input-group flex-nowrap" style="justify-content: center;">
                    <span class="input-group-text" id="addon-wrapping"><svg xmlns="http://www.w3.org/2000/svg"
                            width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                            <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                        </svg>
                    </span>
                    <div class="form-floating">

                        <!-- <span class="input-group-text" id="basic-addon1">@</span> -->
                        <input type="text" class="form-control" name="usr" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Username</label>
                    </div>
                </div>
                <br>
                <div class="input-group flex-nowrap" style="justify-content: center;">
                    <span class="input-group-text" id="addon-wrapping"><svg xmlns="http://www.w3.org/2000/svg"
                            width="16" height="16" fill="currentColor" class="bi bi-key" viewBox="0 0 16 16">
                            <path
                                d="M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8zm4-3a3 3 0 1 0 2.712 4.285A.5.5 0 0 1 7.163 9h.63l.853-.854a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.793-.793-1-1h-6.63a.5.5 0 0 1-.451-.285A3 3 0 0 0 4 5z" />
                            <path d="M4 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                        </svg>
                    </span>
                    <div class="form-floating">
                        <input type="password" class="form-control" name="pass" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Password</label>

                    </div>

                </div>
                <br>
                <div class="input-group flex-nowrap" style="justify-content: center;">
                    
                    <div class="">
                        <?php 
                            if(isset($_GET['id'])) {
                                if($_GET['id'] ==0) { 
                                    echo'<input type="submit" name ="dn"  class="form-control btn btn-primary" value="Đăng nhập">';
                                    
                                }
                                else if ($_GET['id'] ==1) {
                                    echo'<input type="submit" name ="dk" class="form-control btn btn-primary" value="Đăng kí">';
                                    
                                } else if($_GET['id']==2) {
                                    echo'<input type="submit" name ="dn" class="form-control btn btn-primary" value="Đăng nhập">';
                                    echo '<script>alert("Sai thông tin đăng nhập")</script>';
                                } else if($_GET['id']==3) {
                                    echo'<input type="submit" name ="dk" class="form-control btn btn-primary" value="Đăng kí">';
                                    echo '<script>alert("Tài khoản đã tồn tại")</script>';
                                }
                                
                            }
                            else {
                                echo'<input type="submit" name ="dk" class="form-control btn btn-primary" value="Đăng kí">';
                            }

                        ?>
                        

                    </div>

                </div>
                <!-- <input type="button" class="form-control btn btn-primary" value="Đăng nhập"> -->



            </form>
        </div>
    </div>
<script src="node_modules\bootstrap\dist\js\bootstrap.bundle.js"></script>
</body>
</html>